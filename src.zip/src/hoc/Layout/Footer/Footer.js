import React from 'react';

const Footer = () => (
    <div className='mb-0 d-flex align-items-center justify-content-center text-white font-italic' style={{height:'80px', backgroundColor:'black', fontFamily:"Oswald"}}>
        © 2020 Copyright : Miclaude
    </div>
);

export default Footer;