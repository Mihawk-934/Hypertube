import React from 'react';
import MyCarousel from '../MyCarousel/MyCarousel'

const MyOrder = () => {
    return (
        <MyCarousel title="MyOrder" h4="MyOrderh4"/>
    )
}

export default MyOrder;