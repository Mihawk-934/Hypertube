import React from 'react';
import MyCarousel from '../MyCarousel/MyCarousel';

const MyList = () => {
    return (
       <MyCarousel title="MyList" h4="MyListh4"/>
    )
}

export default MyList;